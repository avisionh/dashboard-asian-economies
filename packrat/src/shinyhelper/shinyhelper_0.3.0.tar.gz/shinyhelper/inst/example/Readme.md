This example demonstrates how to use the core functions in the `shinyhelper` package:

* `helper()`  -  this augments each shiny tag (input or output) with an icon of your choice
* `observe_helpers()`  -  this goes in your server.R script, and creates the event handlers for bringing up your help pages.

