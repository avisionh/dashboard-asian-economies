#' Wrapper for Arya and Mount's Approximate Nearest Neighbours (ANN) C++ library
#' 
#' @name RANN-package
#' @aliases RANN
#' @seealso \code{\link{nn2}}
#' @docType package
#' @keywords package
NULL
