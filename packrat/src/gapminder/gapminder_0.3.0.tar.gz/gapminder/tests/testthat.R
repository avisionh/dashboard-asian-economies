library(testthat)
library(gapminder)

test_check("gapminder")
